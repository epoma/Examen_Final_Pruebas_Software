package com.cibertec.pe.almacenlibertad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlmacenlibertadApplicationTests {

	@Test
	void contextLoads() {
	}

}
