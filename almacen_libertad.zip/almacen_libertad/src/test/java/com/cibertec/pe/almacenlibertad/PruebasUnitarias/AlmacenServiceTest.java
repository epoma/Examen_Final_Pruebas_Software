package com.cibertec.pe.almacenlibertad.PruebasUnitarias;

import com.cibertec.pe.almacenlibertad.Entity.Almacen;
import com.cibertec.pe.almacenlibertad.Repository.AlmacenRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class AlmacenServiceTest {

        private final AlmacenRepository almacenRepository = Mockito.mock(AlmacenRepository.class);
        private final AlmacenService almacenService = new AlmacenService(almacenRepository);

        @Test
        void registrarAlmacen() {
            Almacen nuevo = new Almacen(null, "Almacén Sur", "Trujillo");
            Almacen guardado = new Almacen(1, "Almacén Sur", "Trujillo");

            Mockito.when(almacenRepository.save(nuevo)).thenReturn(guardado);

            Almacen resultado = almacenService.registrarAlmacen(nuevo);
            assertNotNull(resultado.getIdAlmacen());
            assertEquals("Almacén Sur", resultado.getNombre());
        }

        @Test
        void listarAlmacenes() {
            Almacen a1 = new Almacen(1, "Central", "Lima");
            Almacen a2 = new Almacen(2, "Norte", "Los Olivos");

            Mockito.when(almacenRepository.findAll()).thenReturn(Arrays.asList(a1, a2));

            List<Almacen> lista = almacenService.listarAlmacenes();
            assertEquals(2, lista.size());
            assertEquals("Central", lista.get(0).getNombre());
        }

        @Test
        void buscarPorId() {
            Almacen almacen = new Almacen(1, "Central", "Lima");
            Mockito.when(almacenRepository.findById(1)).thenReturn(Optional.of(almacen));

            Optional<Almacen> resultado = almacenService.buscarPorId(1);
            assertTrue(resultado.isPresent());
            assertEquals("Central", resultado.get().getNombre());
        }

        @Test
        void actualizarAlmacen() {
            Almacen existente = new Almacen(1, "Central", "Lima");
            Almacen actualizado = new Almacen(1, "Central Actualizado", "Trujillo");

            Mockito.when(almacenRepository.save(actualizado)).thenReturn(actualizado);

            Almacen resultado = almacenService.actualizarAlmacen(actualizado);
            assertEquals("Central Actualizado", resultado.getNombre());
        }

        @Test
        void eliminarAlmacen() {
            almacenService.eliminarAlmacen(1);
            Mockito.verify(almacenRepository).deleteById(1);
        }
    }
