package com.cibertec.pe.almacenlibertad.Entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "detalle_salida")
public class DetalleSalida {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_detalle")
    private Integer idDetalle;

    @ManyToOne
    @JoinColumn(name = "id_salida")
    private Salida salida;

    @ManyToOne
    @JoinColumn(name = "id_producto")
    private Producto producto;

    private Integer cantidad;

    private LocalDate fecha;


    public void setIdDetalleSalida(Integer id) {
    }
}