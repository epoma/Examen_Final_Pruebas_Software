package com.cibertec.pe.almacenlibertad.PruebasUnitarias;
import com.cibertec.pe.almacenlibertad.Entity.Proveedor;
import com.cibertec.pe.almacenlibertad.Repository.ProveedorRepository;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class ProveedorService {

    @Autowired
    private ProveedorRepository proveedorRepo;

    public Proveedor registrarProveedor(Proveedor proveedor) {
        return proveedorRepo.save(proveedor);
    }

    public List<Proveedor> listarProveedores() {
        return proveedorRepo.findAll();
    }

    public Optional<Proveedor> buscarPorId(Integer id) {
        return proveedorRepo.findById(id);
    }

    public Proveedor actualizarProveedor(Proveedor proveedor) {
        return proveedorRepo.save(proveedor);
    }

    public void eliminarProveedor(Integer id) {
        proveedorRepo.deleteById(id);
    }
}

