package com.cibertec.pe.almacenlibertad.Controller;


import com.cibertec.pe.almacenlibertad.Entity.Entrada;
import com.cibertec.pe.almacenlibertad.PruebasUnitarias.EntradaService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/entradas")
public class EntradaController {

    private final EntradaService entradaService;

    public EntradaController(EntradaService entradaService) {
        this.entradaService = entradaService;
    }

    @PostMapping
    public Entrada registrar(@RequestBody Entrada entrada) {
        return entradaService.registrarEntrada(entrada);
    }

    @GetMapping
    public List<Entrada> listar() {
        return entradaService.listarEntradas();
    }

    @GetMapping("/{id}")
    public Optional<Entrada> buscarPorId(@PathVariable Integer id) {
        return entradaService.buscarPorId(id);
    }

    @PutMapping("/{id}")
    public Entrada actualizar(@PathVariable Integer id, @RequestBody Entrada entrada) {
        entrada.setIdEntrada(id);
        return entradaService.actualizarEntrada(entrada);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Integer id) {
        entradaService.eliminarEntrada(id);
    }
}

