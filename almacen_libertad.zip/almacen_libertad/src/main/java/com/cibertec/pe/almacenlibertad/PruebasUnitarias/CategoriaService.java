package com.cibertec.pe.almacenlibertad.PruebasUnitarias;

import com.cibertec.pe.almacenlibertad.Entity.Categoria;
import com.cibertec.pe.almacenlibertad.Repository.CategoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CategoriaService {

    @Autowired
    private CategoriaRepository categoriaRepo;

    public Categoria registrarCategoria(Categoria categoria) {
        return categoriaRepo.save(categoria);
    }

    public List<Categoria> listarCategorias() {
        return categoriaRepo.findAll();
    }

    public Optional<Categoria> buscarPorId(Integer id) {
        return categoriaRepo.findById(id);
    }

    public Categoria actualizarCategoria(Categoria categoria) {
        return categoriaRepo.save(categoria);
    }

    public void eliminarCategoria(Integer id) {
        categoriaRepo.deleteById(id);
    }
}
