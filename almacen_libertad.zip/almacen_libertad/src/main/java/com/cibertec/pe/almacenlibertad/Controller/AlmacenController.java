package com.cibertec.pe.almacenlibertad.Controller;

import com.cibertec.pe.almacenlibertad.Entity.Almacen;
import com.cibertec.pe.almacenlibertad.PruebasUnitarias.AlmacenService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/almacenes")
public class AlmacenController {

    private final AlmacenService almacenService;

    public AlmacenController(AlmacenService almacenService) {
        this.almacenService = almacenService;
    }

    @PostMapping("/Regristar")
    public Almacen registrar(@RequestBody Almacen almacen) {
        return almacenService.registrarAlmacen(almacen);
    }

    @GetMapping
    public List<Almacen> listar() {
        return almacenService.listarAlmacenes();
    }

    @GetMapping("/{id}")
    public Optional<Almacen> buscarPorId(@PathVariable Integer id) {
        return almacenService.buscarPorId(id);
    }

    @PutMapping("/{id}")
    public Almacen actualizar(@PathVariable Integer id, @RequestBody Almacen almacen) {
        almacen.setIdAlmacen(id);
        return almacenService.actualizarAlmacen(almacen);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Integer id) {
        almacenService.eliminarAlmacen(id);
    }
}
