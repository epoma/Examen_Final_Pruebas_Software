package com.cibertec.pe.almacenlibertad.PruebasUnitarias;
import com.cibertec.pe.almacenlibertad.Entity.Entrada;
import com.cibertec.pe.almacenlibertad.Repository.EntradaRepository;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class EntradaService {

    @Autowired
    private EntradaRepository entradaRepo;

    // Registrar nueva entrada
    public Entrada registrarEntrada(Entrada entrada) {
        return entradaRepo.save(entrada);
    }

    // Listar todas las entradas
    public List<Entrada> listarEntradas() {
        return entradaRepo.findAll();
    }

    // Buscar entrada por ID
    public Optional<Entrada> buscarPorId(Integer id) {
        return entradaRepo.findById(id);
    }

    // Actualizar entrada existente
    public Entrada actualizarEntrada(Entrada entrada) {
        return entradaRepo.save(entrada);
    }

    // Eliminar entrada por ID
    public void eliminarEntrada(Integer id) {
        entradaRepo.deleteById(id);
    }
}
