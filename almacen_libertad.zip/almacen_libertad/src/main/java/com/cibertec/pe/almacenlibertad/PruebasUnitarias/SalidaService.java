package com.cibertec.pe.almacenlibertad.PruebasUnitarias;
import com.cibertec.pe.almacenlibertad.Entity.Salida;
import com.cibertec.pe.almacenlibertad.Repository.SalidaRepository;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class SalidaService {

    @Autowired
    private SalidaRepository salidaRepo;

    // Registrar nueva salida
    public Salida registrarSalida(Salida salida) {
        return salidaRepo.save(salida);
    }

    // Listar todas las salidas
    public List<Salida> listarSalidas() {
        return salidaRepo.findAll();
    }

    // Buscar salida por ID
    public Optional<Salida> buscarPorId(Integer id) {
        return salidaRepo.findById(id);
    }

    // Actualizar salida existente
    public Salida actualizarSalida(Salida salida) {
        return salidaRepo.save(salida);
    }

    // Eliminar salida por ID
    public void eliminarSalida(Integer id) {
        salidaRepo.deleteById(id);
    }
}

