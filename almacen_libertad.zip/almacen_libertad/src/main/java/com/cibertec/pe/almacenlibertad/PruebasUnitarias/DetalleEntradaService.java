package com.cibertec.pe.almacenlibertad.PruebasUnitarias;

import com.cibertec.pe.almacenlibertad.Entity.DetalleEntrada;
import com.cibertec.pe.almacenlibertad.Repository.DetalleEntradaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DetalleEntradaService {

    @Autowired
    private DetalleEntradaRepository detalleEntradaRepo;

    public DetalleEntrada registrarDetalleEntrada(DetalleEntrada detalle) {
        return detalleEntradaRepo.save(detalle);
    }

    public List<DetalleEntrada> listarDetallesEntrada() {
        return detalleEntradaRepo.findAll();
    }

    public Optional<DetalleEntrada> buscarPorId(Integer id) {
        return detalleEntradaRepo.findById(id);
    }

    public DetalleEntrada actualizarDetalleEntrada(DetalleEntrada detalle) {
        return detalleEntradaRepo.save(detalle);
    }

    public void eliminarDetalleEntrada(Integer id) {
        detalleEntradaRepo.deleteById(id);
    }
}
