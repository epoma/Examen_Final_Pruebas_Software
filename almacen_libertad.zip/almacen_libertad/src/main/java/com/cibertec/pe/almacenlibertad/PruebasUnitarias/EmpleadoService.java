package com.cibertec.pe.almacenlibertad.PruebasUnitarias;

import com.cibertec.pe.almacenlibertad.Entity.Empleado;
import com.cibertec.pe.almacenlibertad.Repository.EmpleadoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class EmpleadoService {

    @Autowired
    private EmpleadoRepository empleadoRepo;

    public Empleado registrarEmpleado(Empleado empleado) {
        return empleadoRepo.save(empleado);
    }

    public List<Empleado> listarEmpleados() {
        return empleadoRepo.findAll();
    }

    public Optional<Empleado> buscarPorId(Integer id) {
        return empleadoRepo.findById(id);
    }

    public Empleado actualizarEmpleado(Empleado empleado) {
        return empleadoRepo.save(empleado);
    }

    public void eliminarEmpleado(Integer id) {
        empleadoRepo.deleteById(id);
    }
}
