package com.cibertec.pe.almacenlibertad.Controller;


import com.cibertec.pe.almacenlibertad.Entity.Proveedor;
import com.cibertec.pe.almacenlibertad.PruebasUnitarias.ProveedorService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/proveedores")
public class ProveedorController {

    private final ProveedorService proveedorService;

    public ProveedorController(ProveedorService proveedorService) {
        this.proveedorService = proveedorService;
    }

    @PostMapping
    public Proveedor registrar(@RequestBody Proveedor proveedor) {
        return proveedorService.registrarProveedor(proveedor);
    }

    @GetMapping
    public List<Proveedor> listar() {
        return proveedorService.listarProveedores();
    }

    @GetMapping("/{id}")
    public Optional<Proveedor> buscarPorId(@PathVariable Integer id) {
        return proveedorService.buscarPorId(id);
    }

    @PutMapping("/{id}")
    public Proveedor actualizar(@PathVariable Integer id, @RequestBody Proveedor proveedor) {
        proveedor.setIdProveedor(id);
        return proveedorService.actualizarProveedor(proveedor);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Integer id) {
        proveedorService.eliminarProveedor(id);
    }
}

