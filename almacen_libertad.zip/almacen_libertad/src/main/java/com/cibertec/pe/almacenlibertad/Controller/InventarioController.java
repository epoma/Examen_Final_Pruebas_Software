package com.cibertec.pe.almacenlibertad.Controller;


import com.cibertec.pe.almacenlibertad.Entity.Inventario;
import com.cibertec.pe.almacenlibertad.PruebasUnitarias.InventarioService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/inventarios")
public class InventarioController {

    private final InventarioService inventarioService;

    public InventarioController(InventarioService inventarioService) {
        this.inventarioService = inventarioService;
    }

    @PostMapping
    public Inventario registrar(@RequestBody Inventario inventario) {
        return inventarioService.registrarInventario(inventario);
    }

    @GetMapping
    public List<Inventario> listar() {
        return inventarioService.listarInventarios();
    }

    @GetMapping("/{id}")
    public Optional<Inventario> buscarPorId(@PathVariable Integer id) {
        return inventarioService.buscarPorId(id);
    }

    @PutMapping("/{id}")
    public Inventario actualizar(@PathVariable Integer id, @RequestBody Inventario inventario) {
        inventario.setIdInventario(id);
        return inventario;
    }
}
