package com.cibertec.pe.almacenlibertad.Repository;

import com.cibertec.pe.almacenlibertad.Entity.Inventario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InventarioRepository extends JpaRepository<Inventario, Integer> {
}
