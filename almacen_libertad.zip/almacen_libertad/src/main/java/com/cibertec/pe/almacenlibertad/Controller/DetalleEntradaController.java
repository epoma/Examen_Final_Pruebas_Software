package com.cibertec.pe.almacenlibertad.Controller;

import com.cibertec.pe.almacenlibertad.Entity.DetalleEntrada;
import com.cibertec.pe.almacenlibertad.PruebasUnitarias.DetalleEntradaService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/detalles-entrada")
public class DetalleEntradaController {

    private final DetalleEntradaService detalleEntradaService;

    public DetalleEntradaController(DetalleEntradaService detalleEntradaService) {
        this.detalleEntradaService = detalleEntradaService;
    }

    @PostMapping
    public DetalleEntrada registrar(@RequestBody DetalleEntrada detalleEntrada) {
        return detalleEntradaService.registrarDetalleEntrada(detalleEntrada);
    }

    @GetMapping
    public List<DetalleEntrada> listar() {
        return detalleEntradaService.listarDetallesEntrada();
    }

    @GetMapping("/{id}")
    public Optional<DetalleEntrada> buscarPorId(@PathVariable Integer id) {
        return detalleEntradaService.buscarPorId(id);
    }

    @PutMapping("/{id}")
    public DetalleEntrada actualizar(@PathVariable Integer id, @RequestBody DetalleEntrada detalleEntrada) {
        detalleEntrada.setIdDetalle(id);
        return detalleEntradaService.actualizarDetalleEntrada(detalleEntrada);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Integer id) {
        detalleEntradaService.eliminarDetalleEntrada(id);
    }
}

