package com.cibertec.pe.almacenlibertad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlmacenlibertadApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlmacenlibertadApplication.class, args);
                
                System.out.println("Hola El Examen esta Resuelto");
	}

}
