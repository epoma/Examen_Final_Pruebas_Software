package com.cibertec.pe.almacenlibertad.Controller;

import com.cibertec.pe.almacenlibertad.Entity.Salida;
import com.cibertec.pe.almacenlibertad.PruebasUnitarias.SalidaService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/salidas")
public class SalidaController {

    private final SalidaService salidaService;

    public SalidaController(SalidaService salidaService) {
        this.salidaService = salidaService;
    }

    @PostMapping
    public Salida registrar(@RequestBody Salida salida) {
        return salidaService.registrarSalida(salida);
    }

    @GetMapping
    public List<Salida> listar() {
        return salidaService.listarSalidas();
    }

    @GetMapping("/{id}")
    public Optional<Salida> buscarPorId(@PathVariable Integer id) {
        return salidaService.buscarPorId(id);
    }

    @PutMapping("/{id}")
    public Salida actualizar(@PathVariable Integer id, @RequestBody Salida salida) {
        salida.setIdSalida(id);
        return salidaService.actualizarSalida(salida);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Integer id) {
        salidaService.eliminarSalida(id);
    }
}
