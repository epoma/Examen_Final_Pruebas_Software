package com.cibertec.pe.almacenlibertad.Controller;

import com.cibertec.pe.almacenlibertad.Entity.DetalleSalida;
import com.cibertec.pe.almacenlibertad.PruebasUnitarias.DetalleSalidaService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/detalles-salida")
public class DetalleSalidaController {

    private final DetalleSalidaService detalleSalidaService;

    public DetalleSalidaController(DetalleSalidaService detalleSalidaService) {
        this.detalleSalidaService = detalleSalidaService;
    }

    @PostMapping
    public DetalleSalida registrar(@RequestBody DetalleSalida detalleSalida) {
        return detalleSalidaService.registrarDetalleSalida(detalleSalida);
    }

    @GetMapping
    public List<DetalleSalida> listar() {
        return detalleSalidaService.listarDetallesSalida();
    }

    @GetMapping("/{id}")
    public Optional<DetalleSalida> buscarPorId(@PathVariable Integer id) {
        return detalleSalidaService.buscarPorId(id);
    }

    @PutMapping("/{id}")
    public DetalleSalida actualizar(@PathVariable Integer id, @RequestBody DetalleSalida detalleSalida) {
        detalleSalida.setIdDetalleSalida(id);
        return detalleSalidaService.actualizarDetalleSalida(detalleSalida);
    }


    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Integer id) {
        detalleSalidaService.eliminarDetalleSalida(id);
    }
}

