package com.cibertec.pe.almacenlibertad.PruebasUnitarias;

import com.cibertec.pe.almacenlibertad.Entity.Inventario;
import com.cibertec.pe.almacenlibertad.Repository.InventarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class InventarioService {

    @Autowired
    private InventarioRepository inventarioRepo;

    public Inventario registrarInventario(Inventario inventario) {
        return inventarioRepo.save(inventario);
    }

    public List<Inventario> listarInventarios() {
        return inventarioRepo.findAll();
    }

    public Optional<Inventario> buscarPorId(Integer id) {
        return inventarioRepo.findById(id);
    }

    public Inventario actualizarInventario(Inventario inventario) {
        return inventarioRepo.save(inventario);
    }

    public void eliminarInventario(Integer id) {
        inventarioRepo.deleteById(id);
    }
}
