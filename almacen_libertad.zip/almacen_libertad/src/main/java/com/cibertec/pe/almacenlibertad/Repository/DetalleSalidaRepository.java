package com.cibertec.pe.almacenlibertad.Repository;

import com.cibertec.pe.almacenlibertad.Entity.DetalleSalida;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DetalleSalidaRepository extends JpaRepository<DetalleSalida, Integer> {
}
