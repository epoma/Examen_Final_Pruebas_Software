package com.cibertec.pe.almacenlibertad.Repository;

import com.cibertec.pe.almacenlibertad.Entity.Empleado;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmpleadoRepository extends JpaRepository<Empleado, Integer> {
}
