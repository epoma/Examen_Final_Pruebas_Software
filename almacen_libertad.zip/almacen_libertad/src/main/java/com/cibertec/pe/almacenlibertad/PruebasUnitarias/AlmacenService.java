package com.cibertec.pe.almacenlibertad.PruebasUnitarias;

import com.cibertec.pe.almacenlibertad.Entity.Almacen;
import com.cibertec.pe.almacenlibertad.Repository.AlmacenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AlmacenService {

    @Autowired
    private AlmacenRepository almacenRepo;

    public AlmacenService(AlmacenRepository almacenRepository) {
    }

    public Almacen registrarAlmacen(Almacen almacen) {
        return almacenRepo.save(almacen);
    }

    public List<Almacen> listarAlmacenes() {
        return almacenRepo.findAll();
    }

    public Optional<Almacen> buscarPorId(Integer id) {
        return almacenRepo.findById(id);
    }

    public Almacen actualizarAlmacen(Almacen almacen) {
        return almacenRepo.save(almacen);
    }

    public void eliminarAlmacen(Integer id) {
        almacenRepo.deleteById(id);
    }
}


