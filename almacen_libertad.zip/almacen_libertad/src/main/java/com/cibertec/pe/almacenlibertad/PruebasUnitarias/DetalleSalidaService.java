package com.cibertec.pe.almacenlibertad.PruebasUnitarias;

import com.cibertec.pe.almacenlibertad.Entity.DetalleSalida;
import com.cibertec.pe.almacenlibertad.Repository.DetalleSalidaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DetalleSalidaService {

    @Autowired
    private DetalleSalidaRepository detalleSalidaRepo;

    public DetalleSalida registrarDetalleSalida(DetalleSalida detalle) {
        return detalleSalidaRepo.save(detalle);
    }

    public List<DetalleSalida> listarDetallesSalida() {
        return detalleSalidaRepo.findAll();
    }

    public Optional<DetalleSalida> buscarPorId(Integer id) {
        return detalleSalidaRepo.findById(id);
    }

    public DetalleSalida actualizarDetalleSalida(DetalleSalida detalle) {
        return detalleSalidaRepo.save(detalle);
    }

    public void eliminarDetalleSalida(Integer id) {
        detalleSalidaRepo.deleteById(id);
    }
}
