package com.cibertec.pe.almacenlibertad.Repository;

import com.cibertec.pe.almacenlibertad.Entity.Salida;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SalidaRepository extends JpaRepository<Salida, Integer> {
}
