package com.cibertec.pe.almacenlibertad.Entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "almacen")
@Data
public class Almacen {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_almacen")
    private Integer idAlmacen;

    private String nombre;
    private String ubicacion;


    public Almacen(Object o, String almacénSur, String trujillo) {
    }
}
