package com.cibertec.pe.almacenlibertad.Repository;

import com.cibertec.pe.almacenlibertad.Entity.Almacen;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AlmacenRepository extends JpaRepository<Almacen, Integer> {
}
