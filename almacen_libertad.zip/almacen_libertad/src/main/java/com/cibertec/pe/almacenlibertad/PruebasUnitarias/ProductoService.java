package com.cibertec.pe.almacenlibertad.PruebasUnitarias;
import com.cibertec.pe.almacenlibertad.Entity.Producto;
import com.cibertec.pe.almacenlibertad.Repository.ProductoRepository;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class ProductoService {

    @Autowired
    private ProductoRepository productoRepo;

    // Registrar nuevo producto
    public Producto registrarProducto(Producto producto) {
        return productoRepo.save(producto);
    }

    // Listar todos los productos
    public List<Producto> listarProductos() {
        return productoRepo.findAll();
    }

    // Buscar producto por ID
    public Optional<Producto> buscarPorId(Integer id) {
        return productoRepo.findById(id);
    }

    // Actualizar producto existente
    public Producto actualizarProducto(Producto producto) {
        return productoRepo.save(producto);
    }

    // Eliminar producto por ID
    public void eliminarProducto(Integer id) {
        productoRepo.deleteById(id);
    }
}
