package com.cibertec.pe.almacenlibertad.Repository;

import com.cibertec.pe.almacenlibertad.Entity.DetalleEntrada;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DetalleEntradaRepository extends JpaRepository<DetalleEntrada, Integer> {
}
